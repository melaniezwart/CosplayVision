require('./dist/ui-bootstrap-tpls');

module.exports = 'ui.bootstrap';
