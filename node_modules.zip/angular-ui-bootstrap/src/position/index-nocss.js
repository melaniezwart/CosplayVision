require('./position');

var MODULE_NAME = 'ui.bootstrap.module.position';

angular.module(MODULE_NAME, ['ui.bootstrap.position']);

module.exports = MODULE_NAME;
