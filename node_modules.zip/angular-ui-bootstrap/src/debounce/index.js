require('./debounce');

var MODULE_NAME = 'ui.bootstrap.module.debounce';

angular.module(MODULE_NAME, ['ui.bootstrap.debounce']);

module.exports = MODULE_NAME;
