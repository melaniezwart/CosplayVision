require('../position/position.css');
require('./tooltip.css');
module.exports = require('./index-nocss.js');
